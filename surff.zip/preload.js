const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getDeepgramKey: () => ipcRenderer.invoke('get-deepgram-key'),
  generateAnswer: (question) => ipcRenderer.send('generate-answer', question),
  generateAnswerWithScreen: (question) => ipcRenderer.send('generate-answer-with-screen', question),
  analyzeScreen: (customPrompt) => ipcRenderer.send('analyze-screen', customPrompt),
  captureScreen: () => ipcRenderer.send('capture-screen'),
  // Session management
  startSession: (jobDescription) => ipcRenderer.send('start-session', { jobDescription }),
  endSession: () => ipcRenderer.send('end-session'),
  onSessionStarted: (callback) => ipcRenderer.on('session-started', () => callback()),
  onSessionEnded: (callback) => ipcRenderer.on('session-ended', () => callback()),
  // Answer events
  onAnswerChunk: (callback) => ipcRenderer.on('answer-chunk', (_, text) => callback(text)),
  onAnswerDone: (callback) => ipcRenderer.on('answer-done', () => callback()),
  onAnswerError: (callback) => ipcRenderer.on('answer-error', (_, err) => callback(err)),
  onClickThroughToggled: (callback) => ipcRenderer.on('click-through-toggled', (_, val) => callback(val)),
  onScreenCaptureStarted: (callback) => ipcRenderer.on('screen-capture-started', () => callback()),
  onScreenCaptured: (callback) => ipcRenderer.on('screen-captured', () => callback()),
  onScreenCapturedData: (callback) => ipcRenderer.on('screen-captured-data', (_, data) => callback(data)),
  moveWindow: (deltaX, deltaY) => ipcRenderer.send('move-window', { deltaX, deltaY }),
  minimizeWindow: () => ipcRenderer.send('minimize-window'),
  toggleZoom: () => ipcRenderer.send('toggle-zoom'),
});
