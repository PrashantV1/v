const { app, BrowserWindow, ipcMain, globalShortcut, desktopCapturer, screen } = require('electron');
const path = require('path');
const Anthropic = require('@anthropic-ai/sdk');

// ============================================================
// CONFIGURATION — Set your API keys here or via environment variables
// ============================================================
const DEEPGRAM_API_KEY = process.env.DEEPGRAM_API_KEY || '58c04f15683778937a4c2368baf8597814099b53';
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY || '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';

let mainWindow = null;
let anthropic = null;


// Session context
let sessionContext = {
  jobDescription: null,
  sessionStartTime: null,
  isSessionActive: false,
};

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 480,
    height: 600,
    alwaysOnTop: true,
    frame: false,
    transparent: true,
    resizable: true,
    skipTaskbar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  // Hide from screen capture / screen share
  mainWindow.setContentProtection(true);

  // Make it click-through when needed (toggle with hotkey)
  mainWindow.setIgnoreMouseEvents(false);

  mainWindow.loadFile('index.html');

  // Position at top-right corner
  const { screen } = require('electron');
  const primaryDisplay = screen.getPrimaryDisplay();
  const { width } = primaryDisplay.workAreaSize;
  mainWindow.setPosition(width - 500, 50);
}

function setupAnthropicClient() {
  anthropic = new Anthropic({ apiKey: ANTHROPIC_API_KEY });
}

// Detect if question is about system design
function isSystemDesignQuestion(question) {
  const keywords = [
    'system design', 'design a system', 'design system', 'architect', 'architecture',
    'design twitter', 'design uber', 'design netflix', 'design youtube', 'design whatsapp',
    'design instagram', 'design facebook', 'design amazon', 'design google', 'design tiktok',
    'design url shortener', 'design pastebin', 'design dropbox', 'design slack',
    'design chat', 'design messaging', 'design notification', 'design payment',
    'design e-commerce', 'design booking', 'design search', 'design recommendation',
    'design cache', 'design rate limiter', 'design load balancer', 'design database',
    'scalable', 'distributed', 'microservices', 'high availability', 'fault tolerant',
    'how would you design', 'how to design', 'design a', 'build a scalable'
  ];
  const lowerQ = question.toLowerCase();
  return keywords.some(kw => lowerQ.includes(kw));
}

// Stream answer from Claude API
async function generateAnswer(question, imageBase64 = null) {
  if (!anthropic) return;

  try {
    // Build the current message content
    const currentContent = [];
    
    // If we have a screenshot, add it first
    if (imageBase64) {
      currentContent.push({
        type: 'image',
        source: {
          type: 'base64',
          media_type: 'image/png',
          data: imageBase64,
        },
      });
    }
    
    currentContent.push({ type: 'text', text: question });

    // Check if this is a system design question
    const isSystemDesign = isSystemDesignQuestion(question);
    
    // Build system prompt
    let systemPrompt;
    let maxTokens = 2048;
    
    if (isSystemDesign) {
      maxTokens = 4096;
      systemPrompt = `You are an expert system design interviewer assistant. For system design questions, ALWAYS provide:

1. **Requirements Clarification** (functional & non-functional)
2. **High-Level Design** with ASCII diagram
3. **Component Deep Dive** (each major component explained)
4. **Data Model** (key entities and relationships)
5. **API Design** (key endpoints)
6. **Scalability & Trade-offs**

ALWAYS include an ASCII architecture diagram like this:
\`\`\`
┌─────────┐     ┌─────────────┐     ┌─────────┐
│ Client  │────▶│ Load Balancer │────▶│ Servers │
└─────────┘     └─────────────┘     └─────────┘
\`\`\`

Use box-drawing characters (┌ ─ ┐ │ └ ┘ ▶ ▼) for clean diagrams.
Be detailed but structured. Use headers and bullet points.`;
    } else {
      systemPrompt = `You are a helpful interview assistant. Give concise, well-structured answers to interview questions. 
Keep answers brief but thorough — aim for 3-5 key points. 
Use simple language. Do not say "As an AI" or similar disclaimers.
Format with short bullet points when appropriate.
If an image/screenshot is provided, analyze any code, text, or content visible and incorporate it into your answer.`;
    }

    // Add Job Description context if available
    if (sessionContext.jobDescription) {
      systemPrompt += `\n\n=== JOB DESCRIPTION ===\n${sessionContext.jobDescription}\n=== END JOB DESCRIPTION ===\n\nTailor answers to align with this job's requirements and responsibilities.`;
    }

    const stream = await anthropic.messages.stream({
      model: 'claude-sonnet-4-20250514',
      max_tokens: maxTokens,
      system: systemPrompt,
      messages: [{ role: 'user', content: currentContent }],
    });

    for await (const event of stream) {
      if (event.type === 'content_block_delta' && event.delta?.text) {
        mainWindow?.webContents.send('answer-chunk', event.delta.text);
      }
    }

    mainWindow?.webContents.send('answer-done');
  } catch (err) {
    mainWindow?.webContents.send('answer-error', err.message);
  }
}

// Capture screen and return base64 image
async function captureScreen() {
  try {
    const primaryDisplay = screen.getPrimaryDisplay();
    const { width, height } = primaryDisplay.size;
    
    const sources = await desktopCapturer.getSources({
      types: ['screen'],
      thumbnailSize: { width, height },
    });
    
    if (sources.length === 0) {
      return null;
    }
    
    // Get the primary screen
    const source = sources[0];
    const thumbnail = source.thumbnail;
    
    // Convert to base64 PNG
    const base64 = thumbnail.toPNG().toString('base64');
    return base64;
  } catch (err) {
    console.error('Screen capture error:', err);
    return null;
  }
}

// Analyze screen content
async function analyzeScreen(customPrompt = null) {
  mainWindow?.webContents.send('screen-capture-started');
  
  const imageBase64 = await captureScreen();
  
  if (!imageBase64) {
    mainWindow?.webContents.send('answer-error', 'Failed to capture screen');
    return;
  }
  
  mainWindow?.webContents.send('screen-captured');
  
  const prompt = customPrompt || 'Analyze this screen. If there is code visible, explain what it does and identify any issues or improvements. If there is a question visible, answer it. Be concise and helpful.';
  
  await generateAnswer(prompt, imageBase64);
}

app.whenReady().then(() => {
  createWindow();
  setupAnthropicClient();

  // Global hotkeys
  globalShortcut.register('CommandOrControl+Shift+H', () => {
    // Toggle visibility
    if (mainWindow.isVisible()) {
      mainWindow.hide();
    } else {
      mainWindow.show();
    }
  });

  globalShortcut.register('CommandOrControl+Shift+T', () => {
    // Toggle click-through
    const isIgnoring = mainWindow.isIgnoringMouseEvents?.() ?? false;
    mainWindow.setIgnoreMouseEvents(!isIgnoring, { forward: true });
    mainWindow?.webContents.send('click-through-toggled', !isIgnoring);
  });

  // Screen capture hotkey
  globalShortcut.register('CommandOrControl+Shift+S', () => {
    analyzeScreen();
  });
});

// IPC handlers
ipcMain.on('generate-answer', (event, question) => {
  generateAnswer(question);
});

ipcMain.on('generate-answer-with-screen', async (event, question) => {
  const imageBase64 = await captureScreen();
  generateAnswer(question, imageBase64);
});

ipcMain.on('analyze-screen', (event, customPrompt) => {
  analyzeScreen(customPrompt);
});

ipcMain.on('capture-screen', async (event) => {
  const imageBase64 = await captureScreen();
  mainWindow?.webContents.send('screen-captured-data', imageBase64);
});

// Session management
ipcMain.on('start-session', (event, { jobDescription }) => {
  sessionContext.jobDescription = jobDescription || null;
  sessionContext.sessionStartTime = new Date();
  sessionContext.isSessionActive = true;
  mainWindow?.webContents.send('session-started');
});

ipcMain.on('end-session', () => {
  if (!sessionContext.isSessionActive) return;
  sessionContext.isSessionActive = false;
  sessionContext.jobDescription = null;
  mainWindow?.webContents.send('session-ended');
});

ipcMain.handle('get-deepgram-key', () => {
  return DEEPGRAM_API_KEY;
});

ipcMain.on('move-window', (event, { deltaX, deltaY }) => {
  const [x, y] = mainWindow.getPosition();
  mainWindow.setPosition(x + deltaX, y + deltaY);
});

ipcMain.on('minimize-window', () => {
  mainWindow?.minimize();
});

let isZoomed = false;
let originalBounds = null;

ipcMain.on('toggle-zoom', () => {
  if (!mainWindow) return;
  
  if (isZoomed) {
    if (originalBounds) {
      mainWindow.setBounds(originalBounds);
    }
    isZoomed = false;
  } else {
    originalBounds = mainWindow.getBounds();
    const { screen } = require('electron');
    const primaryDisplay = screen.getPrimaryDisplay();
    const { width, height } = primaryDisplay.workAreaSize;
    mainWindow.setBounds({ x: 50, y: 50, width: width - 100, height: height - 100 });
    isZoomed = true;
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
