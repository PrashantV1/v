# Caude - AI-Powered CLI Coding Assistant (SaaS)

A production-ready SaaS CLI tool that provides AI coding assistance through Claude API with subscription-based pricing.

## 🏗️ Architecture

```
User's CLI ←→ Backend API ←→ Claude API
              ├── Authentication & Authorization
              ├── Subscription Management
              ├── Usage Tracking & Billing
              ├── Rate Limiting
              └── API Key Management
```

## 📦 Project Structure

```
caude/
├── packages/
│   ├── backend/          # Node.js/Express API server
│   │   ├── src/
│   │   │   ├── models/   # MongoDB models (User, Usage)
│   │   │   ├── routes/   # API routes (auth, chat, user)
│   │   │   ├── middleware/ # Auth & rate limiting
│   │   │   └── config/   # Plans & pricing config
│   │   └── package.json
│   └── cli/              # CLI tool
│       ├── src/
│       │   ├── commands/ # CLI commands
│       │   ├── config/   # Local config storage
│       │   └── utils/    # API client & helpers
│       └── package.json
└── package.json          # Monorepo root
```

## 💰 Pricing Plans

| Plan | Price | Token Limit | Models | Features |
|------|-------|-------------|--------|----------|
| **Free** | $0/month | 100K tokens | Haiku | Basic code generation |
| **Pro** | $20/month | 2M tokens | Haiku, Sonnet | Advanced features, priority support |
| **Max** | $100/month | 10M tokens | Haiku, Sonnet, Opus | Full AI agent, all models |

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ 
- MongoDB (local or cloud)
- Claude API key from Anthropic

### 1. Install Dependencies

```bash
npm install
```

### 2. Setup Backend

```bash
cd packages/backend
cp .env.example .env
```

Edit `.env` with your credentials:
```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/caude
JWT_SECRET=your-super-secret-jwt-key-change-this
ANTHROPIC_API_KEY=sk-ant-your-api-key-here
NODE_ENV=development
```

Start MongoDB:
```bash
# Windows
mongod

# macOS/Linux
sudo systemctl start mongodb
```

Start backend:
```bash
npm run dev
```

### 3. Setup CLI

In a new terminal:
```bash
cd packages/cli
npm run build
npm link
```

### 4. Use the CLI

```bash
# Register new account
caude register

# Login
caude login

# Start interactive chat
caude chat

# Ask a single question
caude ask "Write a Python function to reverse a string"

# Check account status
caude status

# View usage statistics
caude usage

# Configure API URL (for production)
caude config
```

## 🔧 Development

### Backend Development
```bash
cd packages/backend
npm run dev          # Start with hot reload
npm run build        # Build TypeScript
npm start            # Run production build
```

### CLI Development
```bash
cd packages/cli
npm run dev          # Run CLI in dev mode
npm run build        # Build TypeScript
npm link             # Link globally
```

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register` - Create account
- `POST /api/auth/login` - Login

### Chat
- `POST /api/chat/message` - Send message (returns full response)
- `POST /api/chat/stream` - Stream response (SSE)

### User
- `GET /api/user/me` - Get account info
- `GET /api/user/usage?days=30` - Get usage stats
- `POST /api/user/upgrade` - Upgrade plan

## 🔐 Authentication

The CLI uses two authentication methods:
1. **JWT Token** - For user-facing API calls (`/user/*`)
2. **API Key** - For chat requests (`/chat/*`)

Both are stored securely in the local config file.

## 💳 Monetization Strategy

### Revenue Model
- **Free tier**: Attract users, limited to Haiku
- **Pro ($20/mo)**: Target individual developers
- **Max ($100/mo)**: Target power users & teams
- **Enterprise**: Custom pricing for companies

### Cost Management
- You pay Claude API costs (~$3-15 per 1M tokens)
- Profit margin: 60-80% depending on model usage
- Example: Pro user using 2M Sonnet tokens = $30-60 cost, $20 revenue (subsidized by Max users)

### Scaling Strategy
1. Start with self-hosted backend
2. Add Stripe integration for payments
3. Deploy to cloud (Railway, Render, AWS)
4. Add team features & collaboration
5. Enterprise features (SSO, VPC, etc.)

## 🚢 Deployment

### Backend Deployment (Railway/Render)

1. Push to GitHub
2. Connect to Railway/Render
3. Set environment variables
4. Deploy

### CLI Distribution

```bash
# Publish to npm
cd packages/cli
npm publish

# Users install via:
npm install -g @caude/cli
```

## 📊 Monitoring & Analytics

Track these metrics:
- User signups & churn
- Token usage per plan
- API costs vs revenue
- Popular models/features
- Error rates

## 🔒 Security

- Passwords hashed with bcrypt
- JWT tokens with expiration
- API keys are unique per user
- Rate limiting on all endpoints
- MongoDB injection protection
- CORS configured

## 📈 Future Features

- [ ] Stripe payment integration
- [ ] Team collaboration
- [ ] Code repository integration
- [ ] Custom model fine-tuning
- [ ] Web dashboard
- [ ] VS Code extension
- [ ] Referral program
- [ ] Usage alerts

## 🤝 Business Model

**Target Market**: Developers, startups, dev teams

**Competitive Advantage**:
- Cheaper than Claude Code ($20 vs $20-200)
- More flexible than GitHub Copilot
- Full control over features
- Can add custom models/features

**Marketing Channels**:
- Product Hunt launch
- Dev.to / Hashnode articles
- Twitter/X developer community
- Reddit (r/programming, r/webdev)
- GitHub sponsors

## 📝 License

MIT License - feel free to use for your SaaS business!

## 🆘 Support

For issues or questions:
- GitHub Issues
- Email: support@caude.ai (set up your domain)
- Discord community (optional)

---

**Built with ❤️ for developers who want to build profitable SaaS products**
