#!/usr/bin/env node

import { Command } from 'commander';
import chalk from 'chalk';
import { login, register, logout } from './commands/auth';
import { chat, chatInteractive } from './commands/chat';
import { usage, status } from './commands/user';
import { configure } from './commands/config';

const program = new Command();

program
  .name('jarvis')
  .description('⚡ Just A Rather Very Intelligent System - Your AI coding assistant')
  .version('1.0.0');

program
  .command('login')
  .description('Login to your Jarvis account')
  .action(login);

program
  .command('register')
  .description('Create a new Jarvis account')
  .action(register);

program
  .command('logout')
  .description('Logout from your account')
  .action(logout);

program
  .command('chat')
  .description('Start interactive chat session')
  .option('-m, --model <model>', 'Model to use (haiku, sonnet, opus)', 'sonnet')
  .action(chatInteractive);

program
  .command('ask <question>')
  .description('Ask a single question')
  .option('-m, --model <model>', 'Model to use (haiku, sonnet, opus)', 'sonnet')
  .action(chat);

program
  .command('usage')
  .description('View your usage statistics')
  .option('-d, --days <days>', 'Number of days to show', '30')
  .action(usage);

program
  .command('status')
  .description('Check your account status')
  .action(status);

program
  .command('config')
  .description('Configure CLI settings')
  .action(configure);

program.parse();
