export const MODEL_MAP: Record<string, string> = {
  'haiku': 'claude-3-haiku-20240307',
  'sonnet': 'claude-3-5-sonnet-20241022',
  'opus': 'claude-opus-4-20250514'
};

export const getModelId = (shortName: string): string => {
  return MODEL_MAP[shortName.toLowerCase()] || MODEL_MAP['sonnet'];
};

export const getModelName = (modelId: string): string => {
  const entry = Object.entries(MODEL_MAP).find(([_, id]) => id === modelId);
  return entry ? entry[0] : 'sonnet';
};
