import axios, { AxiosInstance } from 'axios';
import { getApiKey, getToken, getApiUrl } from '../config/store';

export const createApiClient = (): AxiosInstance => {
  const baseURL = getApiUrl();
  
  return axios.create({
    baseURL,
    headers: {
      'Content-Type': 'application/json'
    }
  });
};

export const createAuthenticatedClient = (): AxiosInstance => {
  const baseURL = getApiUrl();
  const apiKey = getApiKey();
  const token = getToken();
  
  return axios.create({
    baseURL,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'X-API-Key': apiKey
    }
  });
};

export const handleApiError = (error: any): string => {
  if (error.response) {
    return error.response.data.error || error.response.data.message || 'API request failed';
  } else if (error.request) {
    return 'No response from server. Is the backend running?';
  } else {
    return error.message || 'Unknown error occurred';
  }
};
