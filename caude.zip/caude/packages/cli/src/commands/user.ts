import chalk from 'chalk';
import ora from 'ora';
import { createAuthenticatedClient, handleApiError } from '../utils/api';
import { isAuthenticated, getEmail } from '../config/store';

export const status = async () => {
  if (!isAuthenticated()) {
    console.log(chalk.red('❌ Please login first: jarvis login'));
    process.exit(1);
  }

  const spinner = ora('Fetching account status...').start();

  try {
    const client = createAuthenticatedClient();
    const response = await client.get('/user/me');

    spinner.stop();

    const user = response.data;
    const percentUsed = ((user.tokensUsed / user.tokenLimit) * 100).toFixed(1);

    console.log(chalk.blue.bold('\n📊 Account Status\n'));
    console.log(chalk.white(`Email: ${user.email}`));
    console.log(chalk.white(`Plan: ${chalk.bold(user.plan.toUpperCase())}`));
    console.log(chalk.white(`API Key: ${user.apiKey}`));
    console.log(chalk.white(`\nTokens Used: ${user.tokensUsed.toLocaleString()} / ${user.tokenLimit.toLocaleString()} (${percentUsed}%)`));
    console.log(chalk.white(`Resets: ${new Date(user.resetAt).toLocaleDateString()}`));
    console.log(chalk.white(`Member Since: ${new Date(user.createdAt).toLocaleDateString()}\n`));

    if (user.tokensUsed / user.tokenLimit > 0.8) {
      console.log(chalk.yellow('⚠️  You are approaching your token limit. Consider upgrading your plan.\n'));
    }
  } catch (error) {
    spinner.fail(chalk.red('Failed to fetch status'));
    console.error(chalk.red(handleApiError(error)));
    process.exit(1);
  }
};

export const usage = async (options: { days: string }) => {
  if (!isAuthenticated()) {
    console.log(chalk.red('❌ Please login first: jarvis login'));
    process.exit(1);
  }

  const spinner = ora('Fetching usage data...').start();

  try {
    const client = createAuthenticatedClient();
    const response = await client.get(`/user/usage?days=${options.days}`);

    spinner.stop();

    const { usage, summary } = response.data;

    console.log(chalk.blue.bold(`\n📈 Usage Statistics (${summary.period})\n`));
    console.log(chalk.white(`Total Requests: ${summary.totalRequests}`));
    console.log(chalk.white(`Total Tokens: ${summary.totalTokens.toLocaleString()}`));
    console.log(chalk.white(`Total Cost: $${summary.totalCost}\n`));

    if (usage.length > 0) {
      console.log(chalk.cyan('Recent Activity:\n'));
      
      usage.slice(0, 10).forEach((u: any) => {
        const date = new Date(u.timestamp).toLocaleString();
        console.log(chalk.gray(`${date} | ${u.model.split('-')[2]} | ${u.totalTokens.toLocaleString()} tokens | $${u.cost.toFixed(4)}`));
      });
      
      if (usage.length > 10) {
        console.log(chalk.gray(`\n... and ${usage.length - 10} more requests\n`));
      }
    } else {
      console.log(chalk.gray('No usage data available.\n'));
    }
  } catch (error) {
    spinner.fail(chalk.red('Failed to fetch usage'));
    console.error(chalk.red(handleApiError(error)));
    process.exit(1);
  }
};
