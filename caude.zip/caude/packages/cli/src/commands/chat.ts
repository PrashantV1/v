import inquirer from 'inquirer';
import chalk from 'chalk';
import ora from 'ora';
import { createAuthenticatedClient, handleApiError } from '../utils/api';
import { getModelId } from '../utils/models';
import { isAuthenticated } from '../config/store';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export const chat = async (question: string, options: { model: string }) => {
  if (!isAuthenticated()) {
    console.log(chalk.red('❌ Please login first: jarvis login'));
    process.exit(1);
  }

  const spinner = ora('Thinking...').start();

  try {
    const client = createAuthenticatedClient();
    const modelId = getModelId(options.model);

    const response = await client.post('/chat/message', {
      model: modelId,
      messages: [
        {
          role: 'user',
          content: question
        }
      ],
      max_tokens: 4096
    });

    spinner.stop();

    const content = response.data.content[0].text;
    console.log(chalk.cyan('\n💬 Jarvis:\n'));
    console.log(chalk.white(content));
    
    console.log(chalk.gray(`\n📊 Usage: ${response.data.usage.total_tokens} tokens | Cost: $${response.data.usage.cost} | Remaining: ${response.data.usage.remaining_tokens.toLocaleString()}\n`));
  } catch (error) {
    spinner.fail(chalk.red('Request failed'));
    console.error(chalk.red(handleApiError(error)));
    process.exit(1);
  }
};

export const chatInteractive = async (options: { model: string }) => {
  if (!isAuthenticated()) {
    console.log(chalk.red('❌ Please login first: jarvis login'));
    process.exit(1);
  }

  console.log(chalk.blue.bold('\n💬 Jarvis Interactive Chat'));
  console.log(chalk.gray(`Model: ${options.model}`));
  console.log(chalk.gray('Type "exit" or "quit" to end the session\n'));

  const messages: Message[] = [];

  while (true) {
    const { input } = await inquirer.prompt([
      {
        type: 'input',
        name: 'input',
        message: chalk.green('You:'),
        validate: (input) => input.trim().length > 0 || 'Please enter a message'
      }
    ]);

    if (input.toLowerCase() === 'exit' || input.toLowerCase() === 'quit') {
      console.log(chalk.yellow('\n👋 Goodbye!\n'));
      break;
    }

    messages.push({
      role: 'user',
      content: input
    });

    const spinner = ora('Thinking...').start();

    try {
      const client = createAuthenticatedClient();
      const modelId = getModelId(options.model);

      const response = await client.post('/chat/message', {
        model: modelId,
        messages: messages,
        max_tokens: 4096
      });

      spinner.stop();

      const content = response.data.content[0].text;
      
      messages.push({
        role: 'assistant',
        content: content
      });

      console.log(chalk.cyan('\nJarvis:\n'));
      console.log(chalk.white(content));
      console.log(chalk.gray(`\n📊 ${response.data.usage.total_tokens} tokens | $${response.data.usage.cost} | ${response.data.usage.remaining_tokens.toLocaleString()} remaining\n`));
    } catch (error) {
      spinner.fail(chalk.red('Request failed'));
      console.error(chalk.red(handleApiError(error)));
      
      messages.pop();
    }
  }
};
