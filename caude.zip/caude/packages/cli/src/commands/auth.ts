import inquirer from 'inquirer';
import chalk from 'chalk';
import ora from 'ora';
import { createApiClient, handleApiError } from '../utils/api';
import { setApiKey, setToken, setEmail, clearAuth, getEmail } from '../config/store';

export const register = async () => {
  console.log(chalk.blue.bold('\n🚀 Create your Jarvis account\n'));

  const answers = await inquirer.prompt([
    {
      type: 'input',
      name: 'email',
      message: 'Email:',
      validate: (input) => input.includes('@') || 'Please enter a valid email'
    },
    {
      type: 'password',
      name: 'password',
      message: 'Password:',
      validate: (input) => input.length >= 6 || 'Password must be at least 6 characters'
    }
  ]);

  const spinner = ora('Creating account...').start();

  try {
    const client = createApiClient();
    const response = await client.post('/auth/register', {
      email: answers.email,
      password: answers.password
    });

    setApiKey(response.data.apiKey);
    setToken(response.data.token);
    setEmail(response.data.user.email);

    spinner.succeed(chalk.green('Account created successfully!'));
    
    console.log(chalk.cyan('\n📊 Account Details:'));
    console.log(chalk.white(`Email: ${response.data.user.email}`));
    console.log(chalk.white(`Plan: ${response.data.user.plan}`));
    console.log(chalk.white(`Token Limit: ${response.data.user.tokenLimit.toLocaleString()}`));
    console.log(chalk.yellow(`\n🔑 API Key: ${response.data.apiKey}`));
    console.log(chalk.gray('(Keep this safe - you can view it later with "jarvis status")\n'));
  } catch (error) {
    spinner.fail(chalk.red('Registration failed'));
    console.error(chalk.red(handleApiError(error)));
    process.exit(1);
  }
};

export const login = async () => {
  console.log(chalk.blue.bold('\n🔐 Login to Jarvis\n'));

  const answers = await inquirer.prompt([
    {
      type: 'input',
      name: 'email',
      message: 'Email:',
      validate: (input) => input.includes('@') || 'Please enter a valid email'
    },
    {
      type: 'password',
      name: 'password',
      message: 'Password:'
    }
  ]);

  const spinner = ora('Logging in...').start();

  try {
    const client = createApiClient();
    const response = await client.post('/auth/login', {
      email: answers.email,
      password: answers.password
    });

    setApiKey(response.data.apiKey);
    setToken(response.data.token);
    setEmail(response.data.user.email);

    spinner.succeed(chalk.green('Login successful!'));
    
    console.log(chalk.cyan('\n📊 Account Status:'));
    console.log(chalk.white(`Email: ${response.data.user.email}`));
    console.log(chalk.white(`Plan: ${response.data.user.plan}`));
    console.log(chalk.white(`Tokens Used: ${response.data.user.tokensUsed.toLocaleString()} / ${response.data.user.tokenLimit.toLocaleString()}`));
    console.log(chalk.gray('\nYou can now use "jarvis chat" to start coding!\n'));
  } catch (error) {
    spinner.fail(chalk.red('Login failed'));
    console.error(chalk.red(handleApiError(error)));
    process.exit(1);
  }
};

export const logout = async () => {
  const email = getEmail();
  
  if (!email) {
    console.log(chalk.yellow('You are not logged in.'));
    return;
  }

  const { confirm } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'confirm',
      message: `Logout from ${email}?`,
      default: true
    }
  ]);

  if (confirm) {
    clearAuth();
    console.log(chalk.green('✓ Logged out successfully'));
  }
};
