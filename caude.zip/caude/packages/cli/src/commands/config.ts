import inquirer from 'inquirer';
import chalk from 'chalk';
import { getApiUrl, setApiUrl } from '../config/store';

export const configure = async () => {
  console.log(chalk.blue.bold('\n⚙️  Configure Jarvis CLI\n'));

  const currentUrl = getApiUrl();

  const answers = await inquirer.prompt([
    {
      type: 'input',
      name: 'apiUrl',
      message: 'API URL:',
      default: currentUrl,
      validate: (input) => {
        try {
          new URL(input);
          return true;
        } catch {
          return 'Please enter a valid URL';
        }
      }
    }
  ]);

  setApiUrl(answers.apiUrl);

  console.log(chalk.green('\n✓ Configuration saved successfully\n'));
  console.log(chalk.white(`API URL: ${answers.apiUrl}\n`));
};
