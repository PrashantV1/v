import Conf from 'conf';

interface ConfigSchema {
  apiKey?: string;
  token?: string;
  email?: string;
  apiUrl: string;
  defaultModel: string;
}

const config = new Conf<ConfigSchema>({
  projectName: 'jarvis-cli',
  defaults: {
    apiUrl: 'http://localhost:3000/api',
    defaultModel: 'claude-3-5-sonnet-20241022'
  }
});

export const getApiKey = (): string | undefined => {
  return config.get('apiKey');
};

export const setApiKey = (apiKey: string): void => {
  config.set('apiKey', apiKey);
};

export const getToken = (): string | undefined => {
  return config.get('token');
};

export const setToken = (token: string): void => {
  config.set('token', token);
};

export const getEmail = (): string | undefined => {
  return config.get('email');
};

export const setEmail = (email: string): void => {
  config.set('email', email);
};

export const getApiUrl = (): string => {
  return config.get('apiUrl');
};

export const setApiUrl = (url: string): void => {
  config.set('apiUrl', url);
};

export const clearAuth = (): void => {
  config.delete('apiKey');
  config.delete('token');
  config.delete('email');
};

export const isAuthenticated = (): boolean => {
  return !!config.get('apiKey') && !!config.get('token');
};

export default config;
