export const PLANS = {
  free: {
    name: 'Free',
    price: 0,
    tokenLimit: 100000,
    models: ['claude-3-haiku-20240307'],
    features: ['Basic code generation', 'Limited to Haiku model', '100K tokens/month']
  },
  pro: {
    name: 'Pro',
    price: 20,
    tokenLimit: 2000000,
    models: ['claude-3-haiku-20240307', 'claude-3-5-sonnet-20241022'],
    features: ['Advanced code generation', 'Sonnet & Haiku models', '2M tokens/month', 'Priority support']
  },
  max: {
    name: 'Max',
    price: 100,
    tokenLimit: 10000000,
    models: ['claude-3-haiku-20240307', 'claude-3-5-sonnet-20241022', 'claude-opus-4-20250514'],
    features: ['Full AI agent capabilities', 'All models (Opus, Sonnet, Haiku)', '10M tokens/month', 'Priority support', 'Advanced features']
  }
};

export const MODEL_PRICING = {
  'claude-3-haiku-20240307': {
    input: 0.00025,
    output: 0.00125
  },
  'claude-3-5-sonnet-20241022': {
    input: 0.003,
    output: 0.015
  },
  'claude-opus-4-20250514': {
    input: 0.015,
    output: 0.075
  }
};
