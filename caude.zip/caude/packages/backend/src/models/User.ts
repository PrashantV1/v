import mongoose, { Document, Schema } from 'mongoose';

export interface IUser extends Document {
  email: string;
  password: string;
  apiKey: string;
  plan: 'free' | 'pro' | 'max';
  tokensUsed: number;
  tokenLimit: number;
  stripeCustomerId?: string;
  stripeSubscriptionId?: string;
  createdAt: Date;
  resetTokensAt: Date;
}

const UserSchema = new Schema<IUser>({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true
  },
  apiKey: {
    type: String,
    required: true,
    unique: true
  },
  plan: {
    type: String,
    enum: ['free', 'pro', 'max'],
    default: 'free'
  },
  tokensUsed: {
    type: Number,
    default: 0
  },
  tokenLimit: {
    type: Number,
    default: 100000
  },
  stripeCustomerId: String,
  stripeSubscriptionId: String,
  createdAt: {
    type: Date,
    default: Date.now
  },
  resetTokensAt: {
    type: Date,
    default: () => {
      const date = new Date();
      date.setMonth(date.getMonth() + 1);
      return date;
    }
  }
});

export default mongoose.model<IUser>('User', UserSchema);
