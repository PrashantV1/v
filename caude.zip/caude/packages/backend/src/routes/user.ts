import express, { Response } from 'express';
import { AuthRequest, authenticateToken } from '../middleware/auth';
import User from '../models/User';
import Usage from '../models/Usage';
import { PLANS } from '../config/plans';

const router = express.Router();

router.get('/me', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user;

    res.json({
      email: user.email,
      plan: user.plan,
      apiKey: user.apiKey,
      tokensUsed: user.tokensUsed,
      tokenLimit: user.tokenLimit,
      resetAt: user.resetTokensAt,
      createdAt: user.createdAt
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user data' });
  }
});

router.get('/usage', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.userId;
    const { days = 30 } = req.query;

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - Number(days));

    const usage = await Usage.find({
      userId,
      timestamp: { $gte: startDate }
    }).sort({ timestamp: -1 });

    const totalCost = usage.reduce((sum, u) => sum + u.cost, 0);
    const totalTokens = usage.reduce((sum, u) => sum + u.totalTokens, 0);

    res.json({
      usage,
      summary: {
        totalRequests: usage.length,
        totalTokens,
        totalCost: totalCost.toFixed(4),
        period: `Last ${days} days`
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch usage data' });
  }
});

router.post('/upgrade', authenticateToken, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user;
    const { plan } = req.body;

    if (!['free', 'pro', 'max'].includes(plan)) {
      return res.status(400).json({ error: 'Invalid plan' });
    }

    const planConfig = PLANS[plan as keyof typeof PLANS];

    user.plan = plan;
    user.tokenLimit = planConfig.tokenLimit;
    await user.save();

    res.json({
      message: 'Plan upgraded successfully',
      plan: user.plan,
      tokenLimit: user.tokenLimit,
      features: planConfig.features
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to upgrade plan' });
  }
});

export default router;
