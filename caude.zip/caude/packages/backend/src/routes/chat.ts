import express, { Response } from 'express';
import Anthropic from '@anthropic-ai/sdk';
import { AuthRequest, authenticateApiKey } from '../middleware/auth';
import { checkTokenLimit, checkModelAccess } from '../middleware/rateLimit';
import Usage from '../models/Usage';
import { MODEL_PRICING } from '../config/plans';

const router = express.Router();
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!
});

router.post('/message', authenticateApiKey, checkTokenLimit, checkModelAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { messages, model = 'claude-3-5-sonnet-20241022', max_tokens = 4096, system } = req.body;
    const user = req.user;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array required' });
    }

    const response = await anthropic.messages.create({
      model,
      max_tokens,
      messages,
      ...(system && { system })
    });

    const inputTokens = response.usage.input_tokens;
    const outputTokens = response.usage.output_tokens;
    const totalTokens = inputTokens + outputTokens;

    const pricing = MODEL_PRICING[model as keyof typeof MODEL_PRICING];
    const cost = (inputTokens * pricing.input) + (outputTokens * pricing.output);

    user.tokensUsed += totalTokens;
    await user.save();

    await Usage.create({
      userId: user._id,
      model,
      inputTokens,
      outputTokens,
      totalTokens,
      cost
    });

    res.json({
      id: response.id,
      model: response.model,
      content: response.content,
      usage: {
        input_tokens: inputTokens,
        output_tokens: outputTokens,
        total_tokens: totalTokens,
        cost: cost.toFixed(4),
        remaining_tokens: user.tokenLimit - user.tokensUsed
      }
    });
  } catch (error: any) {
    console.error('Chat error:', error);
    res.status(500).json({ 
      error: 'Chat request failed',
      details: error.message 
    });
  }
});

router.post('/stream', authenticateApiKey, checkTokenLimit, checkModelAccess, async (req: AuthRequest, res: Response) => {
  try {
    const { messages, model = 'claude-3-5-sonnet-20241022', max_tokens = 4096, system } = req.body;
    const user = req.user;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array required' });
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const stream = await anthropic.messages.create({
      model,
      max_tokens,
      messages,
      stream: true,
      ...(system && { system })
    });

    let inputTokens = 0;
    let outputTokens = 0;

    for await (const event of stream) {
      if (event.type === 'message_start') {
        inputTokens = event.message.usage.input_tokens;
      } else if (event.type === 'message_delta') {
        outputTokens = event.usage.output_tokens;
      } else if (event.type === 'content_block_delta') {
        res.write(`data: ${JSON.stringify(event)}\n\n`);
      }
    }

    const totalTokens = inputTokens + outputTokens;
    const pricing = MODEL_PRICING[model as keyof typeof MODEL_PRICING];
    const cost = (inputTokens * pricing.input) + (outputTokens * pricing.output);

    user.tokensUsed += totalTokens;
    await user.save();

    await Usage.create({
      userId: user._id,
      model,
      inputTokens,
      outputTokens,
      totalTokens,
      cost
    });

    res.write(`data: [DONE]\n\n`);
    res.end();
  } catch (error: any) {
    console.error('Stream error:', error);
    res.write(`data: ${JSON.stringify({ error: error.message })}\n\n`);
    res.end();
  }
});

export default router;
