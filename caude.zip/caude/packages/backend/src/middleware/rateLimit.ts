import { Request, Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
import { PLANS } from '../config/plans';

export const checkTokenLimit = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const user = req.user;

    if (!user) {
      return res.status(401).json({ error: 'User not authenticated' });
    }

    if (new Date() > user.resetTokensAt) {
      user.tokensUsed = 0;
      const nextReset = new Date();
      nextReset.setMonth(nextReset.getMonth() + 1);
      user.resetTokensAt = nextReset;
      await user.save();
    }

    if (user.tokensUsed >= user.tokenLimit) {
      return res.status(429).json({ 
        error: 'Token limit exceeded',
        tokensUsed: user.tokensUsed,
        tokenLimit: user.tokenLimit,
        resetAt: user.resetTokensAt,
        message: 'Upgrade your plan to continue using the service'
      });
    }

    next();
  } catch (error) {
    return res.status(500).json({ error: 'Rate limit check failed' });
  }
};

export const checkModelAccess = (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const user = req.user;
    const requestedModel = req.body.model;

    if (!user) {
      return res.status(401).json({ error: 'User not authenticated' });
    }

    const userPlan = PLANS[user.plan as keyof typeof PLANS];
    
    if (!userPlan.models.includes(requestedModel)) {
      return res.status(403).json({ 
        error: 'Model not available in your plan',
        currentPlan: user.plan,
        availableModels: userPlan.models,
        message: `Upgrade to ${requestedModel.includes('opus') ? 'Max' : 'Pro'} plan to access this model`
      });
    }

    next();
  } catch (error) {
    return res.status(500).json({ error: 'Model access check failed' });
  }
};
